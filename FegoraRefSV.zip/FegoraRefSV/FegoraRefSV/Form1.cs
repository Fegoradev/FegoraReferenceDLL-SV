﻿using Newtonsoft.Json;
using NucLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PruebaLibreriaNuc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Factura
        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();

            //Valores prueba
            string item = "Implementacion";
            double preciouni = 10;
            double qnty = 1;

            //Declaracion del objeto del documento
            Generador.Root Documento = new Generador.Root();

        ///--------------------------------------------
            Documento.Version = "1";
            Documento.CountryCode = "SV";
            ///--------------------------------------------

            //LLenado del Header del documento
           ///--------------------------------------------
            List<Generador.info> ListAdditionalIssueDocInfo = new List<Generador.info>();
            Generador.info AdditionalIssueDocInfo = new Generador.info
            {
                Name = "Secuencial",
                Value = random.Next(0, 9999999).ToString("0000000") + random.Next(0, 99999999).ToString("00000000")
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            AdditionalIssueDocInfo = new Generador.info
            {
                Name = "CodEstPuntoV",
                Value = "1"
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            AdditionalIssueDocInfo = new Generador.info
            {
                Name = "TipoModelo",
                Value = "1"
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            AdditionalIssueDocInfo = new Generador.info
            {
                Name = "TipoOperacion",
                Value = "1"
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

           ///--------------------------------------------
            Documento.Header = new Generador.Header
            {
                DocType = "01",
                IssuedDateTime = DateTime.Now.ToString("s"),
                AdditionalIssueType = "00",
                Currency = "USD",
                AdditionalIssueDocInfo = ListAdditionalIssueDocInfo
            };
           ///--------------------------------------------

            //LLenado del Seller del documento
           ///--------------------------------------------
            List<Generador.info> ListTaxIDAdditionalInfo = new List<Generador.info>();
            Generador.info TaxIDAdditionalInfo = new Generador.info
            {
                Name = "NRC",
                Value = "3225641"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "CodigoActividad",
                Value = "62020"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "DescActividad",
                Value = "Consultorías y gestión de servicios informáticos"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);
           
            ///--------------------------------------------
            List<Generador.info> ListAdditionlInfo = new List<Generador.info>();
            Generador.info AdditionlInfo = new Generador.info
            {
                Name = "NombreComercial",
                Value = "FEGORA"
            };
            ListAdditionlInfo.Add(AdditionlInfo);

            AdditionlInfo = new Generador.info
            {
                Name = "TipoEstablecimiento",
                Value = "02"
            };
            ListAdditionlInfo.Add(AdditionlInfo);

           ///--------------------------------------------
            List<Generador.info> ListAddressInfo = new List<Generador.info>();
            Generador.info AddressInfo = new Generador.info
            {
                Name = "Address",
                Value = "AV. DR. EMILIO ALVAREZ , LOCAL 1O , COL. MEDICA , CENTRO PROFESIONAL SAN FRANCISCO, SAN SALVADOR, SAN SALVADOR"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "District",
                Value = "14"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "State",
                Value = "06"
            };
            ListAddressInfo.Add(AddressInfo);

           ///--------------------------------------------
            List<string> Phones = new List<string>();
            Phones.Add("+502 3028-5755");

           ///--------------------------------------------
            List<string> Emails = new List<string>();
            Emails.Add("ncoronado@fegora.net");

           ///--------------------------------------------
            Documento.Seller = new Generador.Seller
            {
                TaxID = "06141412221065",
                Name = "FEGORA SOCIEDAD ANONIMA DE CAPITAL VARIABLE",
                TaxIDAdditionalInfo = ListTaxIDAdditionalInfo,
                AdditionlInfo = ListAdditionlInfo,
                AddressInfo = new Generador.AddressInfo
                {
                    Address = "AV. DR. EMILIO ALVAREZ , LOCAL 1O , COL. MEDICA , CENTRO PROFESIONAL SAN FRANCISCO, SAN SALVADOR, SAN SALVADOR",
                    District = "14",
                    State = "06",
                    Country = "SV"
                },
                Contact = new Generador.Contact
                {
                    PhoneList = new Generador.PhoneList
                    {
                        Phone = Phones
                    },
                    EmailList = new Generador.EmailList
                    {
                        Email = Emails
                    }
                },

            };
           ///--------------------------------------------

            //Llenado del Buyer
           ///--------------------------------------------
            ListTaxIDAdditionalInfo = new List<Generador.info>();
            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "CodigoActividad",
                Value = "10005"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "DescActividad",
                Value = "Otros"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "TipoPersona",
                Value = "1"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

           ///--------------------------------------------
            List<Generador.info> ListAdditionInfo = new List<Generador.info>();
            Generador.info AdditionInfo = new Generador.info
            {
                Name = "CodPais",
                Value = "SV"
            };
            ListAdditionlInfo.Add(AdditionInfo);

           ///--------------------------------------------
            ListAddressInfo = new List<Generador.info>();
            AddressInfo = new Generador.info
            {
                Name = "Address",
                Value = "AV. DR. EMILIO ALVAREZ , LOCAL 1O , COL. MEDICA , CENTRO PROFESIONAL SAN FRANCISCO, SAN SALVADOR, SAN SALVADOR"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "District",
                Value = "14"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "State",
                Value = "06"
            };
            ListAddressInfo.Add(AddressInfo);

           ///--------------------------------------------
            Phones = new List<string>();
            Phones.Add("+502 3028-5755");

           ///--------------------------------------------
            Emails = new List<string>();
            Emails.Add("ncoronado@fegora.net");

           ///--------------------------------------------
            Documento.Buyer = new Generador.Buyer
            {
                TaxID = "94833110761015",
                TaxIDType = "36",
                TaxIDAdditionalInfo = ListTaxIDAdditionalInfo,
                Name = "NILS EDUARDO CORONADO VASQUEZ",
                Contact = new Generador.Contact
                {
                    PhoneList = new Generador.PhoneList
                    {
                        Phone = Phones
                    },
                    EmailList = new Generador.EmailList
                    {
                        Email = Emails
                    }
                },
                AdditionlInfo = ListAdditionlInfo,
                //AddressInfo = ListAddressInfo
            };
           ///--------------------------------------------

            //Llenado Items
           ///--------------------------------------------
            List<Generador.info> ListAdditionalInfo = new List<Generador.info>();
            Generador.info AdditionalInfo = new Generador.info
            {
                Name = "IvaItem",
                Value = Convert.ToString(11.50442 * (preciouni * qnty) / 100)
            };
            ListAdditionalInfo.Add(AdditionalInfo);
            AdditionalInfo = new Generador.info
            {
                Name = "PrecioSugeridoVenta",
                Value = "0.00"
            };
            ListAdditionalInfo.Add(AdditionalInfo);

           ///--------------------------------------------
            List<Generador.info> Codes = new List<Generador.info>();
            Generador.info Code = new Generador.info
            {
                Name = "Codigo",
                Value = "S00001"
            };
            Codes.Add(Code);

           ///--------------------------------------------
            List<Generador.Charge> charges = new List<Generador.Charge>();
            Generador.Charge charge = new Generador.Charge
            {
                Code = "VENTA_GRAVADA",
                Amount = "10.00"
            };
            charges.Add(charge);

           ///--------------------------------------------
            List<Generador.Tax> taxes = new List<Generador.Tax>();
            Generador.Tax tax = new Generador.Tax
            {
                Amount = "0.00",
                Code = null
            };
            taxes.Add(tax);

           ///--------------------------------------------
            List<Generador.Items> Items = new List<Generador.Items>();
            Generador.Items Item = new Generador.Items
            {

                Number = "1",
                Codes = Codes,
                Qty = qnty,
                Totals = new Generador.ItemTotal
                {
                    TotalItem = preciouni * qnty
                },
                AdditionalInfo = ListAdditionalInfo,
                Description = item,
                UnitOfMeasure = "99",
                Type = "2",
                Taxes = new Generador.Taxes
                {
                    Tax = taxes
                },
                Charges = new Generador.Charges
                {
                    Charge = charges
                },
                Discounts = null,
                Price = preciouni,

            };
            Items.Add(Item);

           ///--------------------------------------------
            Documento.Items = Items;
           ///--------------------------------------------

            //Lllenado Totales
           ///--------------------------------------------
            ListAdditionalInfo = new List<Generador.info>();
            AdditionalInfo = new Generador.info
            {
                Name = "CondicionOperacion",
                Value = "1"
            };
            ListAdditionalInfo.Add(AdditionalInfo);

           ///--------------------------------------------
            List<Generador.TotalCharge> totalCharges = new List<Generador.TotalCharge>();
            Generador.TotalCharge totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_GRAVADA",
                Amount = "10.00"
            };
            totalCharges.Add(totalCharge);

            totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_NO_SUJETA",
                Amount = "0.00"
            };
            totalCharges.Add(totalCharge);

            totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_EXENTA",
                Amount = "0.00"
            };
            totalCharges.Add(totalCharge);

            totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_NO_GRAVADO",
                Amount = "0.00"
            };
            totalCharges.Add(totalCharge);

           ///--------------------------------------------
            Documento.Totals = new Generador.Totals
            {
                TotalTaxes = null,
                TotalCharges = new Generador.TotalCharges
                {
                    TotalCharge = totalCharges
                },
                AdditionalInfo = ListAdditionalInfo,
                GrandTotal = new Generador.GrandTotal
                {
                    InvoiceTotal = "10.00"

                },
                InWords = "Diez",
                TotalDiscount = null

            };
           ///--------------------------------------------

            //Lllenado Payments
           ///--------------------------------------------
            List<Generador.Payment> Payments = new List<Generador.Payment>();
            Generador.Payment Pay = new Generador.Payment
            {
                Amount = 10.00,
                Code = "03"
            };
            Payments.Add(Pay);
           ///--------------------------------------------

            Documento.Payments = Payments;
           ///--------------------------------------------

            //Llenado AdditionalInfo
           ///--------------------------------------------
            List<Generador.info> AdditionalDocumentInfo = new List<Generador.info>();
            Generador.info AddInfo = new Generador.info
            {
                Name = "NombreEntrega",
                Value = "José"
            };

           ///--------------------------------------------
            List<Generador.AdditionalInfo> AditionalInfo = new List<Generador.AdditionalInfo>();
            Generador.AdditionalInfo additional = new Generador.AdditionalInfo
            {
                AdditionalData = null,
                AditionalInfo = AdditionalDocumentInfo
            };
            AditionalInfo.Add(additional);

           ///--------------------------------------------
            AdditionalDocumentInfo.Add(AddInfo);

           ///--------------------------------------------
            Documento.AdditionalDocumentInfo = new Generador.AdditionalDocumentInfo
            {
                AdditionalInfo = AditionalInfo
            };
            ///--------------------------------------------

            string dat = JsonConvert.SerializeObject(Documento);

            // Obtencion de token
            ///--------------------------------------------
            string token = Generador.getToken("SV.06141412221065.FEGORA", "Fegora23*");

            //Envio Documento
           ///--------------------------------------------
            var send = Generador.SendDTE("06141412221065", "FEGORA", Documento, token);

            MessageBox.Show(send);
        }

        //Nota de Credito
        private void button2_Click(object sender, EventArgs e)
        {
            Random random = new Random();

            //Valores prueba
            string item = "Implementacion";
            double preciouni = 10;
            double qnty = 1;

            //Declaracion del objeto del documento
            Generador.Root Documento = new Generador.Root();

            ///--------------------------------------------
            Documento.Version = "3";
            Documento.CountryCode = "SV";
            ///--------------------------------------------

            //LLenado del Header del documento
            ///--------------------------------------------
            List<Generador.info> ListAdditionalIssueDocInfo = new List<Generador.info>();
            Generador.info AdditionalIssueDocInfo = new Generador.info
            {
                Name = "Secuencial",
                Value = random.Next(0, 9999999).ToString("0000000") + random.Next(0, 99999999).ToString("00000000")
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            AdditionalIssueDocInfo = new Generador.info
            {
                Name = "CodEstPuntoV",
                Value = "1"
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            AdditionalIssueDocInfo = new Generador.info
            {
                Name = "TipoModelo",
                Value = "1"
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            AdditionalIssueDocInfo = new Generador.info
            {
                Name = "TipoOperacion",
                Value = "1"
            };
            ListAdditionalIssueDocInfo.Add(AdditionalIssueDocInfo);

            ///--------------------------------------------
            Documento.Header = new Generador.Header
            {
                DocType = "05",
                IssuedDateTime = DateTime.Now.ToString("s"),
                AdditionalIssueType = "00",
                Currency = "USD",
                AdditionalIssueDocInfo = ListAdditionalIssueDocInfo
            };
            ///--------------------------------------------

            //LLenado del Seller del documento
            ///--------------------------------------------
            List<Generador.info> ListTaxIDAdditionalInfo = new List<Generador.info>();
            Generador.info TaxIDAdditionalInfo = new Generador.info
            {
                Name = "NRC",
                Value = "3225641"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "CodigoActividad",
                Value = "62020"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "DescActividad",
                Value = "Consultorías y gestión de servicios informáticos"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            ///--------------------------------------------
            List<Generador.info> ListAdditionlInfo = new List<Generador.info>();
            Generador.info AdditionlInfo = new Generador.info
            {
                Name = "NombreComercial",
                Value = "FEGORA"
            };
            ListAdditionlInfo.Add(AdditionlInfo);

            AdditionlInfo = new Generador.info
            {
                Name = "TipoEstablecimiento",
                Value = "02"
            };
            ListAdditionlInfo.Add(AdditionlInfo);

            ///--------------------------------------------
            List<Generador.info> ListAddressInfo = new List<Generador.info>();
            Generador.info AddressInfo = new Generador.info
            {
                Name = "Address",
                Value = "AV. DR. EMILIO ALVAREZ , LOCAL 1O , COL. MEDICA , CENTRO PROFESIONAL SAN FRANCISCO, SAN SALVADOR, SAN SALVADOR"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "District",
                Value = "14"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "State",
                Value = "06"
            };
            ListAddressInfo.Add(AddressInfo);

            ///--------------------------------------------
            List<string> Phones = new List<string>();
            Phones.Add("+502 3028-5755");

            ///--------------------------------------------
            List<string> Emails = new List<string>();
            Emails.Add("ncoronado@fegora.net");

            ///--------------------------------------------
            Documento.Seller = new Generador.Seller
            {
                TaxID = "06141412221065",
                Name = "FEGORA SOCIEDAD ANONIMA DE CAPITAL VARIABLE",
                TaxIDAdditionalInfo = ListTaxIDAdditionalInfo,
                AdditionlInfo = ListAdditionlInfo,
                AddressInfo = new Generador.AddressInfo
                {
                    Address = "AV. DR. EMILIO ALVAREZ , LOCAL 1O , COL. MEDICA , CENTRO PROFESIONAL SAN FRANCISCO, SAN SALVADOR, SAN SALVADOR",
                    District = "14",
                    State = "06",
                    Country = "SV"
                },
                Contact = new Generador.Contact
                {
                    PhoneList = new Generador.PhoneList
                    {
                        Phone = Phones
                    },
                    EmailList = new Generador.EmailList
                    {
                        Email = Emails
                    }
                },

            };
            ///--------------------------------------------

            //Llenado del Buyer
            ///--------------------------------------------
            ListTaxIDAdditionalInfo = new List<Generador.info>();
            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "CodigoActividad",
                Value = "10005"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "DescActividad",
                Value = "Otros"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            TaxIDAdditionalInfo = new Generador.info
            {
                Name = "TipoPersona",
                Value = "1"
            };
            ListTaxIDAdditionalInfo.Add(TaxIDAdditionalInfo);

            ///--------------------------------------------
            List<Generador.info> ListAdditionInfo = new List<Generador.info>();
            Generador.info AdditionInfo = new Generador.info
            {
                Name = "CodPais",
                Value = "SV"
            };
            ListAdditionlInfo.Add(AdditionInfo);

            ///--------------------------------------------
            ListAddressInfo = new List<Generador.info>();
            AddressInfo = new Generador.info
            {
                Name = "Address",
                Value = "AV. DR. EMILIO ALVAREZ , LOCAL 1O , COL. MEDICA , CENTRO PROFESIONAL SAN FRANCISCO, SAN SALVADOR, SAN SALVADOR"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "District",
                Value = "14"
            };
            ListAddressInfo.Add(AddressInfo);

            AddressInfo = new Generador.info
            {
                Name = "State",
                Value = "06"
            };
            ListAddressInfo.Add(AddressInfo);

            ///--------------------------------------------
            Phones = new List<string>();
            Phones.Add("+502 3028-5755");

            ///--------------------------------------------
            Emails = new List<string>();
            Emails.Add("ncoronado@fegora.net");

            ///--------------------------------------------
            Documento.Buyer = new Generador.Buyer
            {
                TaxID = "94833110761015",
                TaxIDType = "36",
                TaxIDAdditionalInfo = ListTaxIDAdditionalInfo,
                Name = "NILS EDUARDO CORONADO VASQUEZ",
                Contact = new Generador.Contact
                {
                    PhoneList = new Generador.PhoneList
                    {
                        Phone = Phones
                    },
                    EmailList = new Generador.EmailList
                    {
                        Email = Emails
                    }
                },
                AdditionlInfo = ListAdditionlInfo,
                //AddressInfo = ListAddressInfo
            };
            ///--------------------------------------------

            //Llenado Items
            ///--------------------------------------------
            List<Generador.info> ListAdditionalInfo = new List<Generador.info>();
            Generador.info AdditionalInfo = new Generador.info
            {
                Name = "IvaItem",
                Value = Convert.ToString(11.50442 * (preciouni * qnty) / 100)
            };
            ListAdditionalInfo.Add(AdditionalInfo);
            AdditionalInfo = new Generador.info
            {
                Name = "PrecioSugeridoVenta",
                Value = "0.00"
            };
            ListAdditionalInfo.Add(AdditionalInfo);

            ///--------------------------------------------
            List<Generador.info> Codes = new List<Generador.info>();
            Generador.info Code = new Generador.info
            {
                Name = "Codigo",
                Value = "S00001"
            };
            Codes.Add(Code);

            ///--------------------------------------------
            List<Generador.Charge> charges = new List<Generador.Charge>();
            Generador.Charge charge = new Generador.Charge
            {
                Code = "VENTA_GRAVADA",
                Amount = "10.00"
            };
            charges.Add(charge);

            ///--------------------------------------------
            List<Generador.Tax> taxes = new List<Generador.Tax>();
            Generador.Tax tax = new Generador.Tax
            {
                Amount = "0.00",
                Code = null
            };
            taxes.Add(tax);

            ///--------------------------------------------
            List<Generador.Items> Items = new List<Generador.Items>();
            Generador.Items Item = new Generador.Items
            {

                Number = "1",
                Codes = Codes,
                Qty = qnty,
                Totals = new Generador.ItemTotal
                {
                    TotalItem = preciouni * qnty
                },
                AdditionalInfo = ListAdditionalInfo,
                Description = item,
                UnitOfMeasure = "99",
                Type = "2",
                Taxes = new Generador.Taxes
                {
                    Tax = taxes
                },
                Charges = new Generador.Charges
                {
                    Charge = charges
                },
                Discounts = null,
                Price = preciouni,

            };
            Items.Add(Item);

            ///--------------------------------------------
            Documento.Items = Items;
            ///--------------------------------------------

            //Lllenado Totales
            ///--------------------------------------------
            ListAdditionalInfo = new List<Generador.info>();
            AdditionalInfo = new Generador.info
            {
                Name = "CondicionOperacion",
                Value = "1"
            };
            ListAdditionalInfo.Add(AdditionalInfo);

            ///--------------------------------------------
            List<Generador.TotalCharge> totalCharges = new List<Generador.TotalCharge>();
            Generador.TotalCharge totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_GRAVADA",
                Amount = "10.00"
            };
            totalCharges.Add(totalCharge);

            totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_NO_SUJETA",
                Amount = "0.00"
            };
            totalCharges.Add(totalCharge);

            totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_EXENTA",
                Amount = "0.00"
            };
            totalCharges.Add(totalCharge);

            totalCharge = new Generador.TotalCharge
            {
                Code = "TOTAL_NO_GRAVADO",
                Amount = "0.00"
            };
            totalCharges.Add(totalCharge);

            ///--------------------------------------------
            Documento.Totals = new Generador.Totals
            {
                TotalTaxes = null,
                TotalCharges = new Generador.TotalCharges
                {
                    TotalCharge = totalCharges
                },
                AdditionalInfo = ListAdditionalInfo,
                GrandTotal = new Generador.GrandTotal
                {
                    InvoiceTotal = "10.00"

                },
                InWords = "Diez",
                TotalDiscount = null

            };
            ///--------------------------------------------

            //Lllenado Payments
            ///--------------------------------------------
            List<Generador.Payment> Payments = new List<Generador.Payment>();
            Generador.Payment Pay = new Generador.Payment
            {
                Amount = 10.00,
                Code = "03"
            };
            Payments.Add(Pay);
            ///--------------------------------------------

            Documento.Payments = Payments;
            ///--------------------------------------------

            //Llenado AdditionalInfo
            ///--------------------------------------------
            List<Generador.info> AdditionalDocumentInfo = new List<Generador.info>();
            Generador.info AddInfo = new Generador.info
            {
                Name = "NombreEntrega",
                Value = "José"
            }; AdditionalDocumentInfo.Add(AddInfo);
            ///--------------------------------------------
            List<Generador.info> AdditionalDocumentData = new List<Generador.info>();
            Generador.info AddData = new Generador.info
            {
                Name = "TipoDocumento",
                Value = "01"
            };
            AdditionalDocumentData.Add(AddData);

            ///--------------------------------------------
            AddData = new Generador.info
            {
                Name = "NumDocumento",
                Value = "34C673AB-C0B7-45C4-ABFC-FB6EC9EB534B"
            };
            AdditionalDocumentData.Add(AddData);

            ///--------------------------------------------
            AddData = new Generador.info
            {
                Name = "TipoGeneracion",
                Value = "2"
            };
            AdditionalDocumentData.Add(AddData);

            ///--------------------------------------------
            List<Generador.AdditionalInfo> AditionalInfo = new List<Generador.AdditionalInfo>();
            Generador.AdditionalInfo additional = new Generador.AdditionalInfo
            {
                AdditionalData = AdditionalDocumentData,
                AditionalInfo = AdditionalDocumentInfo
            };
            AditionalInfo.Add(additional);

            ///--------------------------------------------
            Documento.AdditionalDocumentInfo = new Generador.AdditionalDocumentInfo
            {
                AdditionalInfo = AditionalInfo
            };
            ///--------------------------------------------

            string dat = JsonConvert.SerializeObject(Documento);

            // Obtencion de token
            ///--------------------------------------------
            string token = Generador.getToken("SV.06141412221065.FEGORA", "Fegora23*");

            //Envio Documento
            ///--------------------------------------------
            var send = Generador.SendDTE("06141412221065", "FEGORA", Documento, token);

            MessageBox.Show(send);
        }
    }
}
